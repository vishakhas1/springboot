package com.example.demo;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Springnod1ApplicationTests {

	@Test
	void contextLoads() {
	}

}
